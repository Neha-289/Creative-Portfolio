function resumeshow(){
	$("#resume").slideDown();
	$("#profile").slideUp();	
	// $("#resume").css("display","block");
	// $("#profile").css("display","none");	
}
function profileshow(){
	$("#profile").slideDown();
	$("#resume").slideUp();
}

$(".tab-link").click(function(){
	 $(".tab-link").removeClass('active');
    $(this).addClass('active');
});
